echo "Installing zip/unzip" 

sudo yum install zip unzip -y 