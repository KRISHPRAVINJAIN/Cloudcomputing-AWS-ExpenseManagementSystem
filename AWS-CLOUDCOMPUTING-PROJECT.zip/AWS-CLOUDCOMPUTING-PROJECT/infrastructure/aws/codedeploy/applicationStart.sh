#!/bin/bash

echo "#CSYE6225: start application pwd and move into nodeapp dir"

pwd

cd /var/webapp_node/webapp

echo "PWD AND FILES"

pwd
sudo pm2 stop app
sudo pm2 start app.js
sudo mkdir -p /opt/node/logs
sudo su
cd ~
# sudo chown root:root ~/.pm2/logs/app-out.log
# sudo chown root:root ~/.pm2/logs/app-error.log

file="/opt/node/logs/appout.log"
if [ ! -f "$file" ]
then
    echo "$0: File '${file}' not found."
    sudo ln /root/.pm2/logs/app-out.log /opt/node/logs/appout.log
fi
file1="/opt/node/logs/apperror.log"
if [ ! -f "$file1" ]
then
    echo "$0: File '${file1}' not found."
    sudo ln /root/.pm2/logs/app-error.log /opt/node/logs/apperror.log
fi




