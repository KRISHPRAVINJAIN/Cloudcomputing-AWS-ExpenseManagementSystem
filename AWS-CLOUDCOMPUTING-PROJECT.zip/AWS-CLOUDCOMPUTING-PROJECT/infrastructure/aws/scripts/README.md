
 # Infrastructure as a Code:
 This readme.md contains steps to build your AWS cloud infrastrcture using AWS CLI
 
 ## Getting Started:
 For this, we will be programming VPC i.e Virtual Private Cloud using AWS CLI.
 
 ## Prerequisites:
 1. VMware Work Station OR
 2. VMware Fusion(Mac) OR
 3. Oracle Virtual Box
 4. Fedora
 5. Pip
 6. AWS CLI
 
 ## Installing pip

```
sudo apt-get install python-pip
```
 
 ## For AWS:
 Check if AWS CLI is installed 
```
$ aws —version
```
 If not installed run the following command
 
```
$ pip install awscli --upgrade --user
```
 Now, we will configure our AWS. Make sure you configure your AWS with your Access Key and Secret Key. In order to set-up the AWS infrastructure, use following command
 
```
$ aws configure
```

## Running Scripts:
Before running the scripts, it is important to make a note that all the scripts, template file should be in the same folder.

To create and configure required networking resources using AWS CLI script :
```
> ./csye6225-aws-networking-setup.sh <VPC_CIDR>
```

To delete networking resources with VPC_ID:
 ```
> ./csye6225-aws-networking-teardown.sh <VPC_ID>
```
 
