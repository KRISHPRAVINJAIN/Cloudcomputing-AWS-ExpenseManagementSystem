#!/usr/bin/bash
VPC_CIDR="$1"

if [ -z "$VPC_CIDR" ]
then
    echo "Please Provide VPC CIDR"
    exit 1
fi


echo "Creating VPC..."
#VPC_CIDR=$(jq -r '.vpc.vpc_cidr' parameters.json)

echo "VPC_CIDR '$VPC_CIDR'"

VPC_ID=$(aws ec2 create-vpc --cidr-block ${VPC_CIDR} --query 'Vpc.{VpcId:VpcId}' --output text)

if [ -z "$VPC_ID" ]
then
    echo "VPC was not Created"
    exit 1
fi
echo "VPC_ID '$VPC_ID"

subnets_id_array=()

for i in {0..5}
do
    echo "Creating subnet $i" 
    SUBNET_CIDR=$(jq -r '.subnets['$i'].subnet_cidr' parameters.json)
    SUBNET_AVAIL=$(jq -r '.subnets['$i'].AvailabilityZone' parameters.json)
    SUBNET_NAME=$(jq -r '.subnets['$i'].name' parameters.json)

    SUBNET=$(aws ec2 create-subnet \
        --vpc-id ${VPC_ID} \
        --cidr-block ${SUBNET_CIDR} \
        --availability-zone ${SUBNET_AVAIL} \
        --query 'Subnet.{SubnetId:SubnetId}' \
        --output text)

    subnets_id_array+=($SUBNET)

    echo "$SUBNET_NAME _CIDR '$SUBNET_CIDR'"

    echo "$SUBNET_NAME _AVAIL '$SUBNET_AVAIL'"

    echo "SUBNET '$SUBNET'"

    aws ec2 create-tags \
        --resources $SUBNET \
        --tags "Key=Name,Value=$SUBNET_NAME"
    
    echo "  Subnet ID '$SUBNET' NAMED as '$SUBNET_NAME'."
    echo ""
done


# #echo "${subnets_id_array[*]}"

echo "Creating Internet Gateway"
GATEWAY_ID=$(aws ec2 create-internet-gateway \
    --query 'InternetGateway.{InternetGatewayId:InternetGatewayId}' \
    --output text)

echo "GATEWAY_ID '$GATEWAY_ID'"
echo ""

echo "Attaching internet gateway to '$VPC_ID'"
aws ec2 attach-internet-gateway --vpc-id ${VPC_ID} --internet-gateway-id ${GATEWAY_ID}
echo ""

echo "Creating Route Table"
ROUTE_TABLE_ID=$(aws ec2 create-route-table \
    --vpc-id ${VPC_ID} \
    --query 'RouteTable.{RouteTableId:RouteTableId}' \
    --output text)

echo "ROUTETABLE_ID '$ROUTE_TABLE_ID'"

echo ""

echo "Attaching all public subnets to route table "

for i in 0 1 2
do
    aws ec2 associate-route-table  \
        --subnet-id ${subnets_id_array[$i]} \
        --route-table-id ${ROUTE_TABLE_ID}
done

echo "Creating public route and adding to route-table"
aws ec2 create-route \
  --route-table-id ${ROUTE_TABLE_ID} \
  --destination-cidr-block 0.0.0.0/0 \
  --gateway-id ${GATEWAY_ID}

exit 0
# echo "$input"