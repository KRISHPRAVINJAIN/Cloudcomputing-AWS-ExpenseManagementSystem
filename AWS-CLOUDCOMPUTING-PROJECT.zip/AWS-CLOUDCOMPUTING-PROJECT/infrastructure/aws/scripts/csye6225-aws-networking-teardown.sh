#!/usr/bin/bash

VPC_ID="$1"

if [ -z "$VPC_ID" ]
then
    echo "Please Provide VPC ID"
    exit 1
fi

# VPC_ID=$(aws ec2 describe-vpcs --filter Name="cidr-block-association.cidr-block",Values="10.0.0.0/16" | jq -r '.Vpcs[].VpcId')
# readarray -t ROUTE_TABLE_IDs < <(aws ec2 describe-route-tables \
#   --filter "Name=vpc-id,Values=${VPC_ID}" "Name=association.main,Values=false" |  jq -c '.RouteTables[].RouteTableId')
ROUTE_TABLE_ID=$(aws ec2 describe-route-tables \
  --filter "Name=vpc-id,Values=${VPC_ID}" "Name=association.main,Values=false" | jq -r '.RouteTables[].RouteTableId')

readarray -t RT_ASSOCIATION_IDs < <(aws ec2 describe-route-tables \
  --filter "Name=vpc-id,Values=${VPC_ID}" "Name=association.main,Values=false" | jq -r '.RouteTables[].Associations[].RouteTableAssociationId')

readarray -t SUBNETS_IDs < <(aws ec2 describe-subnets \
  --filter Name="vpc-id",Values=${VPC_ID} |  jq -r '.Subnets[].SubnetId')

INTERNET_GATEWAY_ID=$(aws ec2 describe-internet-gateways \
  --filter Name="attachment.vpc-id",Values=${VPC_ID} | jq -r '.InternetGateways[].InternetGatewayId')

echo "ROUTE_TABLE_ID: ${ROUTE_TABLE_ID}"
echo "SUBNETS_IDs: ${SUBNETS_IDs[@]}"
echo "RT_ASSOCIATION_IDs: ${RT_ASSOCIATION_IDs[@]}"
echo "INTERNET_GATEWAY_ID: ${INTERNET_GATEWAY_ID}"

echo "Terminating...."
echo "Deleting created route with destination cidr block 0.0.0.0/0"

# for ROUTE_TABLE_ID in ${!ROUTE_TABLE_IDs[@]}
# do
#   echo "Deleting created route with destination cidr block 0.0.0.0/0 and Route table id: ${ROUTE_TABLE_ID}"
#   aws ec2 delete-route \
#     --route-table-id ${ROUTE_TABLE_ID} \
#     --destination-cidr-block 0.0.0.0/0 \
#     || echo "Route Table with ID: ${ROUTE_TABLE_ID} does not contain route with destination cidr block 0.0.0.0/0"
# done

aws ec2 delete-route \
    --route-table-id ${ROUTE_TABLE_ID} \
    --destination-cidr-block 0.0.0.0/0 \
    || echo "Route Table with ID: ${ROUTE_TABLE_ID} does not contain route with destination cidr block 0.0.0.0/0"


echo "Disassociating subnets from route table"
for RT_ASSOCIATION_ID in ${RT_ASSOCIATION_IDs[@]}
do
  echo "Disassociating subnets with association id: ${RT_ASSOCIATION_ID}"
  aws ec2 disassociate-route-table \
    --association-id ${RT_ASSOCIATION_ID} || echo "Could not find subnet with association id: ${RT_ASSOCIATION_ID}"
done

echo "Deleting Route Table with ID: ${ROUTE_TABLE_ID}"
aws ec2 delete-route-table \
  --route-table-id ${ROUTE_TABLE_ID}

echo "Detaching InternetGateway from VPC"
aws ec2 detach-internet-gateway \
  --internet-gateway-id ${INTERNET_GATEWAY_ID} \
  --vpc-id ${VPC_ID}

echo "Deleting InternetGateway..."
aws ec2 delete-internet-gateway \
  --internet-gateway-id ${INTERNET_GATEWAY_ID}

echo "Deleting Subnets..."
for SUBNET_ID in ${SUBNETS_IDs[@]}
do
  aws ec2 delete-subnet \
    --subnet-id ${SUBNET_ID}
done

echo "Deleting VPC"
aws ec2 delete-vpc \
  --vpc-id ${VPC_ID}

echo "Terminating Complete!"

exit 0
