module.exports = {
    getHomePage: (req, res) => {
       
            res.render('main.ejs', {
                title: "Welcome"
                
            });
       
    },
};


